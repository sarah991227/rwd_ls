$(function(){
    $("#hamburger-menu").on("click",function(){
        $("#hamburger-menu").toggleClass("open");
        $(".hammenu").toggleClass("active");
        $("header").toggleClass("active");
    });

    $(".nav >li>a").on("mouseenter",function(){
        $("header").css("background","none");
        $(".sub").stop().slideUp(500);
        $(".nav li a").css("text-decoration","none");

        $("header").css("background","white");
        $(this).css("text-decoration","underline");
        $(this).next().stop().slideDown(500);
    })

    $(".fullmenu").on("mouseleave",function(){
		$("header").css("background","none");
        $(".nav li a").css("background","none");
		$(".sub").stop().slideUp(50);
		$(".nav li a").css("text-decoration","none");
	});

    $(".sub > li >a").on("mouseenter",function(){
        $(".sub li a").css("text-decoration","none");
        $(this).css("text-decoration","underline");
    })

    $(".sub > li > a").on("mouseleave",function(){
		$(".nav li a").css("text-decoration","none");
	});

    $(".sub2 > li >a").on("mouseenter",function(){
        $(".sub2 li a").css("text-decoration","none");
        $(this).css("text-decoration","underline");
    })

    $(".sub2 > li > a").on("mouseleave",function(){
		$(".nav li a").css("text-decoration","none");
	});


    let classname;
    $(".depth1>li").click(function(){

    if($(".depth1").find(".menu-submenu").is(":visible"))
    {
        $(".depth1").find(".menu-submenu").stop().slideUp(500);
        $(".depth1").find(".accordion-toggle").removeClass("active-tab");
        $(".depth1").find(".menu-submenu").removeClass("active-tab");
        
        if(classname != this.getAttribute("class"))
        {
            $(".accordion-toggle",this).removeClass("active-tab");
            $(".accordion-toggle",this).addClass("active-tab");
            $(".menu-submenu",this).removeClass("active-tab");
            $(".menu-submenu",this).addClass("active-tab");
            $(".menu-submenu", this).stop().slideUp(500);
            $(".menu-submenu", this).stop().slideDown(500);
            classname = this.getAttribute("class");
        }
    }
    else
    {
        //first time
        //if nothing is visible 
        $(".accordion-toggle",this).removeClass("active-tab")
        $(".accordion-toggle",this).addClass("active-tab");
        //adding activetab class to accordion-toggle
        $(".menu-submenu",this).removeClass("active-tab");
        $(".menu-submenu",this).addClass("active-tab");
        //adding activetab class to children element menusubmenu
        //now menu submenu is visible
        $(".depth1").find(".menu-submenu").stop().slideUp(500);
        $(".menu-submenu", this).stop().slideDown(500);
        classname = this.getAttribute("class");
    }
    });


    $('.intro').mousewheel(function(e){
        //delta 쓴게 mousewheel plugin 쓴거임
        if(e.deltaY<0){
            // delta 가 0 보다 작았을땐 마우스를 내렸을때
            // delta 가 0 보다 클땐 마우스를 올렸을대
            $('.intro,.content').addClass('scrolled');
        }
    });
    $(window).mousewheel(function(e){
         if($(window).scrollTop()==0 && e.deltaY >0){
            // scrollTop 이 0 일땐 꼭때기 , 그리고 마우스 올릴때 스크롤 클라스를떼라
                $('.intro, .content').removeClass('scrolled');
        }
    });
    
    const imgItems = $('.slider li').length;
    let imgPos = 1;
    for(let i = 1;i<=imgItems;i++){
        $('.pagination').append('<li><span>●</span></li>');
    }
    $('.slider li').hide();
    $('.slider li:first').show();
    $('.pagination li:first').css({'color':'#000'});


    $('.pagination li').click(pagination);


    function pagination(){
        const paginationPos = $(this).index() + 1;
        $('.slider li').hide();
        $('.slider li:nth-child(' + paginationPos + ')').fadeIn();
        $('.pagination li').css({'color':'#ddd'});
        $('.pagination li:nth-child(' + paginationPos + ')').css({'color':'#000'});
        imgPos = paginationPos;
    }
    function nextSlider(){
        if(imgPos >= imgItems){
            imgPos = 1;
        }else{imgPos++;}
        $('.slider li').hide();
        $('.slider li:nth-child(' + imgPos + ')').fadeIn();
        $('.pagination li').css({'color':'#ddd'});
        $('.pagination li:nth-child('+imgPos + ')').css({'color':'#000'});
    }

    setInterval(function(){
        nextSlider();
    },3000);
})